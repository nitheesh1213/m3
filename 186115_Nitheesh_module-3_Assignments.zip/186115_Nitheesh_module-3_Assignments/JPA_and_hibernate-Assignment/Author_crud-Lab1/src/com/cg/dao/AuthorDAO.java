package com.cg.dao;

import com.cg.entities.Author;

public interface AuthorDAO {
	
	public void addAuthor(Author author);
	public void removeAuthor(Author author);
	public void updateAuthor(Author author);
	public Author findAuthor(int authorid);

}
