package com.cg.dao;

import javax.persistence.EntityManager;

import com.cg.db.db;
import com.cg.entities.Author;

public class AuthorDAOImpl implements AuthorDAO {

	db configuration;
	EntityManager entityManager;
	public AuthorDAOImpl(){
		configuration=new db();
		entityManager= configuration.getManager();
	}
	@Override
	public void addAuthor(Author a) {
		entityManager.getTransaction().begin();
		entityManager.persist(a);
		entityManager.flush();
		entityManager.getTransaction().commit();
	}

	@Override
	public void removeAuthor(Author a) {
		entityManager.getTransaction().begin();
		entityManager.remove(a);
		entityManager.flush();
		entityManager.getTransaction().commit();

	}

	@Override
	public void updateAuthor(Author a) {
		entityManager.getTransaction().begin();
		entityManager.merge(a);
		entityManager.flush();
		entityManager.getTransaction().commit();

	}

	@Override
	public Author findAuthor(int aid) {
		return entityManager.find(Author.class, aid);
	}

}
