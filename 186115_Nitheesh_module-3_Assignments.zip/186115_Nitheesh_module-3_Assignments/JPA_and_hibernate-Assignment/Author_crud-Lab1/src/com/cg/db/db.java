package com.cg.db;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class db {

	private static EntityManagerFactory entityManagerFactory; 
	private static EntityManager entityManager;
	static{
		entityManagerFactory= Persistence.createEntityManagerFactory("JPA-PU");
	}
	
	public EntityManager getManager() {
		
		if(entityManager==null || !entityManager.isOpen())
			entityManager=entityManagerFactory.createEntityManager();
		else
			getManager();
		return entityManager;
	}
	
}
